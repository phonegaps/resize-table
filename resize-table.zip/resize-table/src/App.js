
import ResizableTables from './components/resizableTables/ResizableTables';
import TableContent from './components/resizableTables/TableContent';
import OrderInfo from './components/resizableTables/OrderInfo';

function App() {

  const tableHeaders = [
    "Items",
    "Order #",
    "Amount",
    "Status",
    "Delivery Driver",
  ];

  return (
    <div className="App">
      <ResizableTables
        headers={tableHeaders}
        minCellWidth={120}
        tableContent={<TableContent />}
        title='Resize Grid'
      />
      <OrderInfo />
    </div>
  );
}

export default App;
